# Matia Dosen Portfolio Clone

Standalone React + Vite implementation of the published `https://matiadosen.com` portfolio. The source of truth is the frozen production capture in `references/`; unpublished Framer editor changes and excluded draft routes are not included.

## AI/model handoff

Start with [`docs/ai-handoff/00_READ_ME_FIRST.md`](docs/ai-handoff/00_READ_ME_FIRST.md). It provides a low-token loading strategy, architecture map, route/content inventory, exact responsive and interaction notes, current verification status, and a ready-to-paste prompt for another model.

## Local development

```sh
npm install
npm run dev
```

## Production output

```sh
npm run lint
npm test
npm run build
npm run serve
```

`npm run build` writes prerendered route indexes and `404.html` to `dist/`. `npm run serve` serves known files from `http://127.0.0.1:4173` and returns the 404 document with an actual HTTP 404 for unknown paths.

## Environment

- `VITE_SITE_URL` defaults to `https://matiadosen.com` and controls canonical/Open Graph URLs.
- `VITE_CONTACT_ENDPOINT` is optional. Without it, the local contact form is visibly unavailable and cannot submit. When set, the form posts `Name`, `Email`, `Message`, and an empty `website` honeypot as `FormData`.

## Verification

- `npm run crawl` checks statuses, metadata, assets, console errors, internal links, and the unknown-route 404 while the production server is running.
- `npm run capture` refreshes the production reference capture.
- `npm run vendor:assets` localizes Framer-hosted media discovered by the capture.
- `npm run visual:test` captures all 70 route/view combinations and writes measurements to `references/visual-results.json` plus local/diff images.
